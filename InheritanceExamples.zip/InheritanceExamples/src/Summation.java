
public class Summation extends Addition {

	public void mul() {
		System.out.println("MUl");
	}
}
