
public interface Bike {

	public void breaks();

	public void tire();

	public void engine();

	public void petrolTank();
	
	public void headLight();
}
