
public class BikeImpl2 implements Bike {

	@Override
	public void breaks() {
		System.out.println("Breaks2");
	}

	@Override
	public void tire() {
		System.out.println("tire2");

	}

	@Override
	public void engine() {
		System.out.println("engine2");

	}

	@Override
	public void petrolTank() {
		System.out.println("petrol tank2");
	}

	@Override
	public void headLight() {
		System.out.println("HeadLight2");
	}

}
