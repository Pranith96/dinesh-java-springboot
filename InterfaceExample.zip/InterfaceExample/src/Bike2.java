
public interface Bike2 {

	public void breaks();

	public void tire();

	public void engine();

	public void petrolTank();
	
	public void headLight();
}
