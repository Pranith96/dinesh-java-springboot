
public class BikeImpl implements Bike,Bike2 {

	public void breaks() {
		System.out.println("Breaks");
	}

	public void tire() {
		System.out.println("tire");
	}

	public void engine() {
		System.out.println("engine");
	}

	public void petrolTank() {
		System.out.println("petrol tank");
	}

	public void headLight() {
		System.out.println("HeadLight");
	}

}
