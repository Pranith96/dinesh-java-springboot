
public class BikeImpl3 extends BikeImpl2 {

	@Override
	public void headlight() {

		System.out.println("Headlight");

	}

}
