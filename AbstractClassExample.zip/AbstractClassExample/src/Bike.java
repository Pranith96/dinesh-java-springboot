
public abstract class Bike {

	public void tire() {
		System.out.println("Tire");
	}

	public abstract void engine();

	public abstract void seat();

}
