
public abstract class BikeImpl1 extends Bike {

	public void engine() {
		System.out.println("engine");
	}

	public abstract void seat();

	public abstract void breaks();

	public void petrolTank() {
		System.out.println("Petrol tank");
	}

}
