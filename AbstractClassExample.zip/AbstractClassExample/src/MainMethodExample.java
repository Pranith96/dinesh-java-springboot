
public class MainMethodExample {

	public static void main(String[] args) {

		BikeImpl3 bike = new BikeImpl3();
		bike.headlight();
		bike.engine();
		bike.petrolTank();
		bike.seat();
		bike.tire();
		bike.breaks();
	}

}
