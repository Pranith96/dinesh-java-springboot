
public class Subtraction extends Summation {

	public void hi() {
		System.out.println("Hi");
	}
}
