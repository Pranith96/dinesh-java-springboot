package com.methodoverriding;

public class Addition {

	public void add(int a, int b, int c) {
		System.out.println("addition : " + (a + b + c));
	}
	
	public void sub(int a, int b, int c) {
		System.out.println("addition : " + (a + b + c));
	}
}
