
public class MainMethod {

	public static void main(String[] args) {

		Summation summation = new Summation();
		summation.add();
		summation.mul();
		summation.sub();

		Subtraction subtraction = new Subtraction();
		subtraction.add();
		subtraction.hi();
		subtraction.sub();

	}
}
