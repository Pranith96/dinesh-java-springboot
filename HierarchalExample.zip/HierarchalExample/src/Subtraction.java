
public class Subtraction extends Addition {

	public void hi() {
		System.out.println("Hi");
	}
}
