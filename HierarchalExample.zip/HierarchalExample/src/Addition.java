
public class Addition {

	public void add() {
		System.out.println("Add");
	}

	public void sub() {
		System.out.println("Sub");
	}
}
